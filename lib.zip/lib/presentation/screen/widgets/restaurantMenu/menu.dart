import 'package:local_basket/core/constants/colors.dart';
import 'package:flutter/material.dart';
import 'package:local_basket/data/model/restaurants/menu_content_model.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shimmer/shimmer.dart';

class MenuItemWidget extends StatefulWidget {
  final Content item;
  final int quantity;
  final bool isCouponFlow; // <--- add this

  final dynamic restaurantId;
  final String? restaurantName;
  final Function(int) onQuantityChanged;

  const MenuItemWidget({
    super.key,
    required this.item,
    required this.quantity,
    required this.onQuantityChanged,
    required this.restaurantId,
    this.restaurantName,
    this.isCouponFlow = false,
  });

  @override
  State<MenuItemWidget> createState() => _MenuItemWidgetState();
}

class _MenuItemWidgetState extends State<MenuItemWidget> {
  late int quantity;
  bool showItem = true;
  String? comingSoonText;
  bool isBeforeStartTime = false;
  bool _imageLoaded = false;

  @override
  void initState() {
    super.initState();
    quantity = widget.quantity;
  }

  @override
  void didUpdateWidget(covariant MenuItemWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.quantity != widget.quantity && quantity != widget.quantity) {
      quantity = widget.quantity;
    }
  }

  bool computeVisibility(Content item) {
    comingSoonText = null;
    isBeforeStartTime = false;

    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);

    String? startTime;
    String? endTime;

    for (var attr in item.attributes) {
      if (attr.attributeName?.toLowerCase() == 'starttime') {
        startTime = attr.attributeValue;
      } else if (attr.attributeName?.toLowerCase() == 'endtime') {
        endTime = attr.attributeValue;
      }
    }

    if (item.available == true) {
      if (startTime != null) {
        final parts = startTime.split(':');
        if (parts.length >= 2) {
          final start = DateTime(
            today.year,
            today.month,
            today.day,
            int.parse(parts[0]),
            int.parse(parts[1]),
          );

          if (now.isBefore(start)) {
            isBeforeStartTime = true;
            final time = TimeOfDay.fromDateTime(start);
            comingSoonText = 'Available after ${time.format(context)}';
          }
        }
      }
      return true;
    }

    if (endTime != null) {
      final parts = endTime.split(':');
      if (parts.length >= 2) {
        final end = DateTime(
          today.year,
          today.month,
          today.day,
          int.parse(parts[0]),
          int.parse(parts[1]),
        );

        if (now.isBefore(end)) {
          isBeforeStartTime = true;
          final time = TimeOfDay.fromDateTime(end);
          comingSoonText = 'Available after ${time.format(context)}';
          return true;
        } else {
          return true;
        }
      }
    }

    return true;
  }

  void updateQuantity(int newQty) async {
    setState(() => quantity = newQty);
    widget.onQuantityChanged(newQty);
  }

  void _handleAdd() {
    updateQuantity(quantity + 1);
  }

  double? _toDouble(dynamic value) {
    if (value == null) return null;
    if (value is num) return value.toDouble();
    if (value is String) return double.tryParse(value);
    return null;
  }

  String _formatPrice(dynamic value) {
    final price = _toDouble(value);
    if (price == null) return '0';
    if (price % 1 == 0) return price.toStringAsFixed(0);
    return price.toStringAsFixed(2);
  }

  @override
  Widget build(BuildContext context) {
    showItem = computeVisibility(widget.item);
    if (!showItem) return const SizedBox.shrink();

    final item = widget.item;
    final isUnavailable = item.available != true;
    final mediaUrl =
        item.media?.isNotEmpty == true ? item.media!.first.url : null;

    final typeAttr = item.attributes.firstWhere(
      (attr) => attr.attributeName?.toLowerCase() == 'type',
      orElse:
          () => Attribute(id: null, attributeName: null, attributeValue: null),
    );
    final isVeg = item.foodType == 'veg' || typeAttr.attributeValue?.toLowerCase() == 'veg';

    final onlinePriceAttr = item.attributes.firstWhere(
      (attr) => attr.attributeName?.toLowerCase() == 'onlineprice',
      orElse:
          () => Attribute(id: null, attributeName: null, attributeValue: null),
    );
    final priceValue =
        _toDouble(onlinePriceAttr.attributeValue) ?? _toDouble(item.price);
    final priceText = "₹${_formatPrice(priceValue)}";

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: isUnavailable
            ? Colors.grey[300]
            : (isBeforeStartTime ? Colors.grey : Colors.white),
        borderRadius: BorderRadius.circular(16),
        boxShadow: const [
          BoxShadow(color: Colors.black12, blurRadius: 8, offset: Offset(0, 4)),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: SizedBox(
              height: 140,
              width: 140,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  if (mediaUrl == null)
                    Positioned.fill(
                      child: Container(
                        color: Colors.grey.shade200,
                        alignment: Alignment.center,
                        child: Icon(
                          Icons.fastfood,
                          size: 48,
                          color: Colors.grey.shade400,
                        ),
                      ),
                    ),
                  if (mediaUrl != null && !_imageLoaded)
                    Positioned.fill(
                      child: Shimmer.fromColors(
                        baseColor: Colors.grey.shade300,
                        highlightColor: Colors.grey.shade100,
                        child: Container(color: Colors.grey.shade300),
                      ),
                    ),
                  if (mediaUrl != null)
                    Positioned.fill(
                      child: Image.network(
                        mediaUrl,
                        fit: BoxFit.cover,
                        loadingBuilder: (context, child, loadingProgress) {
                          if (loadingProgress == null) {
                            if (!_imageLoaded) {
                              WidgetsBinding.instance.addPostFrameCallback((_) {
                                if (mounted) {
                                  setState(() => _imageLoaded = true);
                                }
                              });
                            }
                            return child;
                          }
                          // While loading, show shimmer behind
                          return const SizedBox.shrink();
                        },
                        errorBuilder: (_, __, ___) {
                          if (!_imageLoaded) {
                            WidgetsBinding.instance.addPostFrameCallback((_) {
                              if (mounted) setState(() => _imageLoaded = true);
                            });
                          }
                          return Container(
                            color: Colors.grey.shade200,
                            alignment: Alignment.center,
                            child: Icon(
                              Icons.fastfood,
                              size: 48,
                              color: Colors.grey.shade400,
                            ),
                          );
                        },
                      ),
                    ),
                  if (isBeforeStartTime)
                    Positioned.fill(
                      child: Container(
                        color: Colors.black.withOpacity(0.5),
                        alignment: Alignment.center,
                        child: Text(
                          comingSoonText ?? "Coming Soon",
                          style: GoogleFonts.poppins(
                            color: Colors.white,
                            fontWeight: FontWeight.w600,
                            fontSize: 13,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                  Align(
                    alignment: Alignment.bottomCenter,
                    child: Padding(
                      padding: const EdgeInsets.only(bottom: 8.0),
                      child:
                          isBeforeStartTime || item.available != true
                              ? Container(
                                height: 36,
                                alignment: Alignment.center,
                                child: Text(
                                  comingSoonText ?? "Unavailable",
                                  style: GoogleFonts.poppins(
                                    color: Colors.grey.shade600,
                                    fontSize: 13,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              )
                              : quantity == 0
                              ? ElevatedButton(
                                onPressed: () {
                                  if (widget.isCouponFlow) {
                                    // Coupon flow → force qty=1
                                    updateQuantity(1);
                                  } else {
                                    _handleAdd();
                                  }
                                },
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.white,
                                  elevation: 2,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                ),
                                child: Text(
                                  "ADD",
                                  style: GoogleFonts.poppins(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 16,
                                    color: Colors.green,
                                  ),
                                ),
                              )
                              : Container(
                                height: 36,
                                decoration: BoxDecoration(
                                  color: AppColor.White,
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 6,
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    GestureDetector(
                                      onTap: () {
                                        if (quantity > 0) {
                                          updateQuantity(quantity - 1);
                                        }
                                      },
                                      child: const Icon(
                                        Icons.remove,
                                        color: Colors.redAccent,
                                        size: 18,
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 12,
                                      ),
                                      child: Text(
                                        '$quantity',
                                        style: GoogleFonts.poppins(
                                          fontWeight: FontWeight.w600,
                                          fontSize: 18,
                                        ),
                                      ),
                                    ),
                                    GestureDetector(
                                      onTap: () {
                                        print("><><<><<${widget.isCouponFlow}");
                                        if (widget.isCouponFlow) {
                                          // 🚫 disable increment beyond 1 in coupon flow
                                          return;
                                        }
                                        _handleAdd();
                                      },
                                      child: Icon(
                                        Icons.add,
                                        color:
                                            widget.isCouponFlow
                                                ? Colors
                                                    .grey // greyed out in coupon flow
                                                : AppColor.PrimaryColor,
                                        size: 18,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    vegNonVegIcon(isVeg),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Text(
                        item.name ?? '',
                        style: GoogleFonts.poppins(
                          fontWeight: FontWeight.w600,
                          fontSize: 15,
                          color: isUnavailable ? Colors.grey : null,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  priceText,
                  style: GoogleFonts.poppins(
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                    color: isUnavailable ? Colors.grey : null,
                  ),
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    const Icon(Icons.star, color: Colors.green, size: 16),
                    const SizedBox(width: 4),
                    Text("4.5", style: GoogleFonts.poppins(fontSize: 12)),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  item.description ??
                      "Juicy meat on a stick, perfect for sharing. Serves 1–2",
                  style: GoogleFonts.poppins(
                    fontSize: 12,
                    color: Colors.grey[600],
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

Future<bool?> showReplaceCartDialog({
  required BuildContext context,
  required String currentRestaurant,
  required String newRestaurant,
}) async {
  return showDialog<bool>(
    context: context,
    barrierDismissible: false,
    builder:
        (context) => Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          backgroundColor: Colors.white,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(
                  Icons.shopping_cart_outlined,
                  size: 48,
                  color: Colors.deepOrange,
                ),
                const SizedBox(height: 16),
                Text(
                  'Replace items in your cart?',
                  textAlign: TextAlign.center,
                  style: GoogleFonts.poppins(
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 12),
                Text.rich(
                  TextSpan(
                    children: [
                      const TextSpan(text: 'Your cart contains dishes from '),
                      TextSpan(
                        text: currentRestaurant,
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.black,
                        ),
                      ),
                      const TextSpan(
                        text: '.\n\nDo you want to discard and add items from ',
                      ),
                      TextSpan(
                        text: newRestaurant,
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.black,
                        ),
                      ),
                      const TextSpan(text: '?'),
                    ],
                  ),
                  textAlign: TextAlign.center,
                  style: GoogleFonts.poppins(
                    fontSize: 14,
                    color: Colors.grey[700],
                  ),
                ),
                const SizedBox(height: 24),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => Navigator.pop(context, false),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: Colors.black87,
                          side: const BorderSide(color: Colors.black26),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                          padding: const EdgeInsets.symmetric(vertical: 12),
                        ),
                        child: const Text("No"),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () => Navigator.pop(context, true),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.deepOrange,
                          foregroundColor: Colors.white,
                          elevation: 2,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                          padding: const EdgeInsets.symmetric(vertical: 12),
                        ),
                        child: const Text("Replace"),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
  );
}

Widget vegNonVegIcon(bool isVeg) {
  return Container(
    width: 16,
    height: 16,
    decoration: BoxDecoration(
      border: Border.all(color: isVeg ? Colors.green : Colors.red, width: 1.5),
      borderRadius: BorderRadius.circular(4),
    ),
    child: Center(
      child: Container(
        width: 8,
        height: 8,
        decoration: BoxDecoration(
          color: isVeg ? Colors.green : Colors.red,
          shape: BoxShape.circle,
        ),
      ),
    ),
  );
}
